import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import './css/style.css';
import registerServiceWorker from './registerServiceWorker';
import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

import {reducer} from './reducers/checkWinner';
import Cells from './components/Cells';
import Shapes from './components/Shapes';
import WinModalContainer from './components/WinModalContainer';
import DrawGameModalContainer from './components/DrawGameModalContainer';
import CharSelectModalContainer from './components/CharSelectModalContainer';
// import {centerCell} from './layouts/Layouts';
import {checkDrawGame, checkWinner, claimCell, chooseChar} from './actions/actions.js';



// Initial State
export const initialState = {
  availableCells: [1,2,3,4,5,6,7,8,9],
  xCells: [],
  oCells: [],
  activePlayer: 'x',
  winner: null,
  drawGame: false,
  cpu: null
}


/************************* Store ***************************/

export const store = createStore(reducer, applyMiddleware(thunk));


/******************** (thunk) Action Creators ************************/

// if player chooses O, CPU (X) will choose random cell for first move
export const chooseCharFirstMove = (char) => {
  return (dispatch, getState) => {
    dispatch(chooseChar(char));
    let { cpu, activePlayer } = getState();
    if (cpu === activePlayer) {
      let randomIndex = Math.floor(Math.random() * 9);
      let randomUnclaimed = [1,2,3,4,5,6,7,8,9][randomIndex];
      dispatch(claimCellIfAvailable(randomUnclaimed));
    }
  }
}

export const claimCellIfAvailable = (cellId) => {
  return (dispatch, getState) => {
    // 1. claim cell
    dispatch(claimCell(cellId));

    {
      // 2-a check winner
      let { xCells, oCells } = getState();
      if ([...xCells, ...oCells].length >= 5) {
        dispatch(checkWinner());
      }
    }

    {// 2-b check draw game
      let { availableCells } = getState();
      if (availableCells.length === 0) {
        dispatch(checkDrawGame());
      }
    }

    // 3. if cpu turn, dispatch cpuTurn
    let { cpu, activePlayer, availableCells } = getState();
    if (cpu === activePlayer && availableCells.length !== 0) {
      dispatch(cpuTurn(availableCells))
    }
  };
}

const cpuTurn = (availableCells) => {
  return (dispatch) => {
    // CPU turn logic: if cpu's turn, choose a random unclaimed cell, recurse
    let randomIndex = Math.floor(Math.random() * (availableCells.length));
    let randomAvailable = availableCells[randomIndex];
    dispatch(claimCellIfAvailable(randomAvailable));
  }
}


const GameBoard = (props) => {
  return (
    <div className='game-board'>
      <svg viewBox={"0 0 600 600"} >
        <Shapes />
        <Cells />
        <CharSelectModalContainer />
        <WinModalContainer />
        <DrawGameModalContainer />
      </svg>
    </div>
  )
}


/************ Root Render Function**************/
const render = () => {
  ReactDOM.render(
    <GameBoard />,
    document.getElementById('root')
  )
};

render();
store.subscribe(render);

registerServiceWorker();
