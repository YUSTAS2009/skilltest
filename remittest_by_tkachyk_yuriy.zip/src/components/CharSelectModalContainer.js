import React, { Component } from 'react';
import {store, chooseCharFirstMove} from '../index.js';
import {XButton, OButton, CharSelectModal} from '../layouts/Layouts.js';


class CharSelectModalContainer extends Component {
  render() {
    let modalVisible = !store.getState().cpu ? true : false;
    if (modalVisible) {
      return (
        <g>
          <CharSelectModal />
          <XButton onClick={()=>store.dispatch(chooseCharFirstMove('x'))} />
          <OButton onClick={()=>store.dispatch(chooseCharFirstMove('o'))} />
        </g>
      )
    }
    return null
  }
}

export default CharSelectModalContainer;
