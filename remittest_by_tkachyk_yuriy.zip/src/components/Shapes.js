import React, { Component } from 'react';
import {store} from '../index.js';
import {XShape, OShape} from '../layouts/Layouts.js';


class Shapes extends Component {
  render() {
    let xCells = store.getState().xCells;
    let oCells = store.getState().oCells;

    return (
      <g className="shapes">
        {xCells.map((cellId, i) => <XShape id={cellId} key={i} /> )}
        {oCells.map((cellId, i) => <OShape id={cellId} key={i} /> )}
      </g>
    )
  }
}

export default Shapes;
