import React, { Component } from 'react';
import {store, claimCellIfAvailable} from '../index.js';
import {Cell} from '../layouts/Layouts.js';


class Cells extends Component {
  render() {
    // (x,y) coords of top left corner of each rect
    let cellCoords = [
      [5,5],[205,5],[405,5],
      [5,205],[205,205],[405,205],
      [5,405],[205,405],[405,405]
    ]

    return (
      <g className="cells">
        {cellCoords.map((curr, i) =>
          <Cell
            x = {curr[0]}
            y = {curr[1]}
            id = {i+1}
            key = {"cell"+i+1}
            onClick = {() => store.dispatch(claimCellIfAvailable(i+1))}
          />
        )}
      </g>
    )
  }
}

export default Cells;
