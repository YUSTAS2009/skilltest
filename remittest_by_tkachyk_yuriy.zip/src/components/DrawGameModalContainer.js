import React, { Component } from 'react';
import {store} from '../index.js';
import {DrawGameModal} from '../layouts/Layouts.js';


class DrawGameModalContainer extends Component {
  render() {
    if (store.getState().drawGame) {
      return <DrawGameModal />
    }
    return null
  }
}

export default DrawGameModalContainer;
