import React, { Component } from 'react';
import {store} from '../index.js';
import {WinModal} from '../layouts/Layouts.js';


class WinModalContainer extends Component {
  render() {
    let modalVisible = store.getState().winner ? true : false;
    if (modalVisible) {
      let winner = store.getState().winner.toUpperCase();
      return <WinModal value={winner} />
    }
    return null
  }
}

export default WinModalContainer;
